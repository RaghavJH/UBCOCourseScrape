package ca.ubc.okanagan.core;

import java.util.ArrayList;

public class Courses extends ArrayList<Course> {

	private static final long serialVersionUID = 1L;
	
}
