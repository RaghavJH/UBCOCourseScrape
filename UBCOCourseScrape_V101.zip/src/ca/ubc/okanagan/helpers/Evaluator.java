package ca.ubc.okanagan.helpers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Evaluator {
	
	private static ArrayList<String[]> keyList = new ArrayList<String[]>();
	
	public static String evaluate(String toEvaluate) {
		return secondRound(firstRound(toEvaluate.toLowerCase()));
	}
	
	private static String firstRound(String toEvaluate) {
		
		if(!toEvaluate.contains("one of") && !toEvaluate.contains("all of")) {
			return "n/a";
		}
		
		Pattern pattern ;//= Pattern.compile(regex, Pattern.MULTILINE);
		Matcher matcher; //= pattern.matcher(string);
		
		for(String[] key : keyList) {
			//Load each key as a pattern from the file
			//Thiks is the first part provided in 1:2:3 format
			pattern = Pattern.compile(key[0], Pattern.MULTILINE);
			
			//SEe if there is a match
			matcher = pattern.matcher(toEvaluate);

			//Loop over found matches
			while(matcher.find()) {
				
				String match = matcher.group(0);
				
//				System.out.println("Match found: " + match);
				
				//Retrieve content from the sentence based on the regex provided in file
				//This is the 2nd part provided in 1:2:3 format.
				ArrayList<String> courses = getContentFromSentence(match, key[1]);
				
				//The delimiter to separate the contents extracted with.
				//This is the 3rd part provided in 1:2:3 format.
				String delimiter = key[2];
				
				StringBuilder booleanExpr = new StringBuilder();
				
				//Start with a bracket to encapsulate everything
				booleanExpr.append("(");
				
				try {
					//If more than 2 courses are extracted then run a for loop.
					if(courses.size() > 2) {
						for(int i = 0; i < courses.size(); i++) {
							//If it is the last course being appended, don't include the delimiter
							if(i == courses.size() - 1)
								booleanExpr.append(courses.get(i));
							else //Otherwise include the delimiter
								booleanExpr.append(courses.get(i) + delimiter);
						}
					//IF only 2 courses are extracted, run this.
					} else {
						booleanExpr.append(courses.get(0) + delimiter + courses.get(1));
					}
				} catch(Exception e) {
					System.out.println(e.getMessage());
				}
				
				//End with a bracket
				booleanExpr.append(")");
				
				
				toEvaluate = toEvaluate.replace(match, booleanExpr.toString());
			}	
		}
		
		return toEvaluate;
	}
	
	private static String secondRound(String toEvaluate) {
		return toEvaluate
				//Replace all and with * and all or with ||.
				.replace("and", "*")
				.replace("or", "||")
				//Replaces dirty * and || that have spaces before, after, or both.
				.replace(" * ", "*")
				.replace(" || ", "||")
				.replace(" *", "*")
				.replace("* ", "*")
				.replace(" ||", "||")
				.replace("|| ", "||");
	}
	
	public static void loadKeys() {
		try(
				BufferedReader in = new BufferedReader(new FileReader(new File("keywords.dat")));
				) {
			String input = null;
			while((input = in.readLine()) != null) {
				if(!input.startsWith("#")) { 
					keyList.add(input.split(":"));
				}
			}
		} catch(IOException e) {
			System.out.println("Error in IO.");
		}
	}
	
	private static ArrayList<String> getContentFromSentence(String sentence, String regex) {
		Matcher m = Pattern.compile(regex, Pattern.MULTILINE)
						.matcher(sentence);
		
		ArrayList<String> content = new ArrayList<String>(5);
		
		while(m.find()) {
			content.add(m.group(0));
		}
		
		return content;
	}
	
}
